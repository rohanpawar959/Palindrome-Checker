package rohan.palindromechecker;

import java.net.URISyntaxException;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.app.AlertDialog.Builder;
import android.app.AlertDialog;

public class PalindromeChecker extends Activity {

    // On startup the onCreate method is executed.
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Display layout from res/layout/main.xml
        // The R.java file is generated and found in
        // gen/edu.cmu.andrew.mm6/R.java

        setContentView(R.layout.main);

        // Use the XML id attribute in the main.xml file to
        // locate buttons. The R.java file was generated from
        // the main.xml and may be used to access pointers
        // to the button views. An Android "view" is similar
        // to a Java Swing component (say a JButton).

        Button okButton = (Button)findViewById(R.id.ok_button);
        Button clearButton = (Button)findViewById(R.id.clear_button);

        if(okButton == null){
            // button was not defined in main.xml
            // trouble

        }else{
            // add a listener to the button
            okButton.setOnClickListener(new OnClickListener(){
                // @Override
                public void onClick(View viewParam) {
                    // Define an intent.
                    Intent myIntent = null;
                    try {
                        // We need to read the text the user entered.
                        // Point to it with keyWordEditText.

                        EditText keyWordEditText = (EditText)findViewById(R.id.keyword_entry);

                        if(keyWordEditText == null){
                            // keyword_entry was not defined in main.xml
                            // trouble
                        }else{
                            // Read the text and convert to string.
                            String keyword1 = keyWordEditText.getText().toString();
                            String keyword=keyword1.toLowerCase();
                            if(keyword.length() == 0){
                                // No text entered. Set the focus back to the
                                // text entry view.
                                keyWordEditText.requestFocus();
                            }else
                                {
                                // Replace any spaces with %20 so that the
                                // text may be passed in a URL.
                                keyword = keyword.replace(" ", "%20");

                                // Create an Intent with an action and a URL.
                                int f = -1;
                                int l=keyword.length();

                                for(int i=0;i<=l/2;i++)
                                {
                                    if(keyword.charAt(i)!=keyword.charAt(l-1-i))
                                    {
                                        f=1;
                                        break;
                                    }
                                }
                                EditText keyWordEditText1 = (EditText)findViewById(R.id.keyword_entry1);

                                    if(f==-1)
                                    keyWordEditText1.setText(" "+keyword1+" is a Palindrome");
                                else
                                    keyWordEditText1.setText(""+keyword1+" is not a Palindrome");
                                }
                            }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    // Start the activity.
                    // This will start up a browser to handle the response.
                    // An Intent is an abstract description of an action to be performed.
                    if(myIntent != null)
                        startActivity(myIntent);
                }
            }); // end of button listener
        }

        // Establish a listener for the clear button.
        if(clearButton == null){
            // The button was not defined in main.xml
            // There is trouble here.
        }
        else
        {

            clearButton.setOnClickListener(new OnClickListener(){

                // @Override
                public void onClick(View viewParam) {

                    // Set up a pointer to the text area.
                    EditText keyWordEditText = (EditText)findViewById(R.id.keyword_entry);
                    EditText keyWordEditText1 = (EditText)findViewById(R.id.keyword_entry1);

                    if(keyWordEditText == null){
                        // Missing in main.xml
                    }else{
                        // clear text area
                        keyWordEditText.setText("");
                        keyWordEditText1.setText("");

                    }
                }
            });
        }
    }
}